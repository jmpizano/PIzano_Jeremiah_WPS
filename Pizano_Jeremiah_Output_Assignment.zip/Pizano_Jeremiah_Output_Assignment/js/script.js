/**
 * Created by JP on 3/5/15.
 */
// Jeremiah Pizano
    // Date: 03-05-2015
    // Class: SDI
// Assignment: Output

// variables
var mySchool = "Riverbank High School."; // This will display what high school I graduated from.
var yearsToGraduate = 3; // This will display how long I attended high school.
var myMajor = true; // I do attend Full Sail.

//display
console.log("It is " + myMajor + " That I am currently enrolled in Full Sail University.");
console.log("Before I came to FUll Sail, I attended " + mySchool);
console.log("I was able to graduate high school in " + yearsToGraduate + " years.");